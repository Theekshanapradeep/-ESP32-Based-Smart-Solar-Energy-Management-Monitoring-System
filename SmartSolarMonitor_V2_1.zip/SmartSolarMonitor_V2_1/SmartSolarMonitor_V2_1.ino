/*************************************************
   Smart Solar Monitor V1.0
   PART 1
*************************************************/

#include <WiFi.h>
#include <WebServer.h>

WebServer server(80);

//=============== WiFi Hotspot ==================
const char* ssid = "SmartSolar";
const char* password = "12345678";

//=============== Voltage Sensors ===============
#define BATTERY_VOLTAGE_PIN 34
#define SOLAR_VOLTAGE_PIN   35

//=============== Current Sensors ===============
#define SOLAR_CURRENT_PIN   32
#define BATTERY_CURRENT_PIN 33

//=============== PIR ===========================
#define PIR_PIN 25

//=============== LDR ===========================
#define LDR_PIN 14

//=============== Relays ========================
#define RELAY1 26
#define RELAY2 27

//=============== Calibration ===================

const float VOLTAGE_MULTIPLIER = 5.0;

const float sensitivity = 0.100;

const float solarOffset = 2.41089;

const float batteryOffset = 2.37396;

//=============== Relay States ==================

bool relay1State = false;
bool relay2State = false;

//==============================
// System Mode
//==============================

bool autoMode = false;      // false = MANUAL
                             // true  = AUTO

unsigned long motionTimer = 0;

const int BATTERY_LIMIT = 30;

const unsigned long LIGHT_DELAY = 30000;   //30 seconds
//=============== Read Voltage ==================

float readVoltage(int pin)
{
  long sum = 0;

  for (int i = 0; i < 500; i++)
  {
    sum += analogRead(pin);
  }

  float adc = sum / 500.0;

  float voltage = adc * (3.3 / 4095.0);

  return voltage * VOLTAGE_MULTIPLIER;
}

//=============== Read Current ==================

float readCurrent(int pin, float offset)
{
  long sum = 0;

  for (int i = 0; i < 2000; i++)
  {
    sum += analogRead(pin);
  }

  float adc = sum / 2000.0;

  float voltage = adc * (3.3 / 4095.0);

  float current = (voltage - offset) / sensitivity;

  current = abs(current);

  if (current < 0.03)
    current = 0;

  return current;
}

//=============== Battery Percentage ============

int batteryPercent(float voltage)
{
  int percent = map((int)(voltage * 100), 950, 1280, 0, 100);

  if (percent > 100)
    percent = 100;

  if (percent < 0)
    percent = 0;

  return percent;
}//=====================================================
// Setup
//=====================================================
//=====================================================
// Generate Web Page
//=====================================================

String page()
{
  float batteryVoltage = readVoltage(BATTERY_VOLTAGE_PIN);
  float solarVoltage   = readVoltage(SOLAR_VOLTAGE_PIN);

  float batteryCurrent = readCurrent(BATTERY_CURRENT_PIN, batteryOffset);
  float solarCurrent   = readCurrent(SOLAR_CURRENT_PIN, solarOffset);

  float batteryPower = batteryVoltage * batteryCurrent;
  float solarPower   = solarVoltage * solarCurrent;

  int battery = batteryPercent(batteryVoltage);

  String motion = digitalRead(PIR_PIN) ? "DETECTED" : "NO MOTION";
  String light  = digitalRead(LDR_PIN) ? "NIGHT" : "DAY";

  String relay1 = relay1State ? "ON" : "OFF";
  String relay2 = relay2State ? "ON" : "OFF";

  String battColor = "#4CAF50";

  if(battery<60)
      battColor="#FFC107";

  if(battery<30)
      battColor="#F44336";

  String solarStatus="NOT GENERATING";

  if(solarPower>1)
      solarStatus="GENERATING";

  String html="";

  html+="<!DOCTYPE html><html>";

  html+="<head>";

  html+="<meta name='viewport' content='width=device-width, initial-scale=1'>";

 

  html+="<title>Smart Solar Monitor</title>";

  html+="<style>";

  html+="body{background:#eef3fb;font-family:Arial;margin:0;padding:18px;}";

  html+=".header{background:#1565C0;color:white;padding:16px;border-radius:18px;text-align:center;font-size:38px;font-weight:bold;}";

  html+=".sub{font-size:18px;margin-top:8px;color:#DDEEFF;}";

  html+=".card{background:white;margin-top:18px;border-radius:18px;padding:22px;box-shadow:0 5px 12px rgba(0,0,0,.15);}";

  html+="h2{color:#1565C0;font-size:28px;margin:0 0 10px 0;}";

  html+="p{font-size:18px;margin:8px 0;}";

  html+="button{width:135px;height:50px;font-size:18px;border:none;border-radius:12px;color:white;margin:5px;}";

  html+=".on{background:#43A047;}";

  html+=".off{background:#E53935;}";

  html+=".bar{width:100%;height:28px;background:#DDD;border-radius:20px;overflow:hidden;}";

  html+=".fill{height:28px;}";

  html+=".badge{display:inline-block;padding:6px 14px;border-radius:20px;color:white;font-size:16px;}";

  html+="</style>";

  html+="</head>";

  html+="<body>";

  html+="<div class='header'>SMART SOLAR MONITOR";
  html += "<div style='margin-top:15px;'>";

if(autoMode)
{
  html += "<span class='badge' style='background:#4CAF50;'>AUTO MODE</span>";
}
else
{
  html += "<span class='badge' style='background:#2196F3;'>MANUAL MODE</span>";
}

html += "</div>";

  html+="<div class='sub'>ESP32 Smart Energy System<br><span style='color:#4CAF50;font-weight:bold'> ONLINE</span></div>";

  html+="</div>";
  html += "<div class='card'>";

html += "<h2>System Mode</h2>";

if(autoMode)
{
    html += "<p><b>Current Mode :</b> AUTO</p>";
}
else
{
    html += "<p><b>Current Mode :</b> MANUAL</p>";
}

html += "<a href='/manual'><button class='off'>MANUAL</button></a>";

html += "<a href='/auto'><button class='on'>AUTO</button></a>";

html += "</div>";

  html+="<div class='card'>";

  html+="<h2>Battery</h2>";

 

  html+="<p><b>Current :</b> "+String(batteryCurrent,2)+" A</p>";

  html+="<p><b>Power :</b> "+String(batteryPower,2)+" W</p>";

  html+="<p><b>Battery Level :</b> "+String(battery)+"%</p>";

  html+="<div class='bar'>";

  html+="<div class='fill' style='width:"+String(battery)+"%;background:"+battColor+";'></div>";

  html+="</div>";

  html+="</div>";

  html+="<div class='card'>";

  html+="<h2>Solar</h2>";

  html+="<p><b>Voltage :</b> "+String(solarVoltage,2)+" V</p>";

  html+="<p><b>Current :</b> "+String(solarCurrent,2)+" A</p>";

  html+="<p><b>Power :</b> "+String(solarPower,2)+" W</p>";
   //------------- Solar Status -----------------

  html += "<p><b>Status :</b> ";

  if(solarPower > 1)
    html += "<span class='badge' style='background:#4CAF50;'>GENERATING</span>";
  else
    html += "<span class='badge' style='background:#F44336;'>NOT GENERATING</span>";

  html += "</p>";

  html += "</div>";

  //------------- Environment ------------------

  html += "<div class='card'>";

  html += "<h2>Environment</h2>";

  html += "<p><b>Motion :</b> ";

  if(digitalRead(PIR_PIN))
    html += "<span class='badge' style='background:#4CAF50;'>DETECTED</span>";
  else
    html += "<span class='badge' style='background:#757575;'>NO MOTION</span>";

  html += "</p>";

  html += "<p><b>Light :</b> ";

  if(digitalRead(LDR_PIN))
    html += "<span class='badge' style='background:#283593;'>NIGHT</span>";
  else
    html += "<span class='badge' style='background:#FFC107;color:black;'>DAY</span>";

  html += "</p>";

  html += "</div>";

  //------------- Relay 1 ------------------

  html += "<div class='card'>";

html += "<h2> Inverter</h2>";

  html += "<p><b>Status :</b> ";

  if(relay1State)
      html += "<span class='badge' style='background:#4CAF50;'>ON</span>";
  else
      html += "<span class='badge' style='background:#F44336;'>OFF</span>";

  html += "</p>";

 if(autoMode)
{
    html += "<p style='color:#E53935;'><b>Battery Protection Mode Active</b></p>";
}
else
{
    html += "<a href='/r1on'><button class='on'>TURN ON</button></a>";

    html += "<a href='/r1off'><button class='off'>TURN OFF</button></a>";
} 
  html += "</div>";

  //------------- Relay 2 ------------------

  html += "<div class='card'>";

 html += "<h2> Smart Light</h2>";

  html += "<p><b>Status :</b> ";

  if(relay2State)
      html += "<span class='badge' style='background:#4CAF50;'>ON</span>";
  else
      html += "<span class='badge' style='background:#F44336;'>OFF</span>";

  html += "</p>";

  if(autoMode)
{
    html += "<p style='color:#E53935;'><b>Motion + Night Control Active</b></p>";
}
else
{
    html += "<a href='/r2on'><button class='on'>TURN ON</button></a>";

    html += "<a href='/r2off'><button class='off'>TURN OFF</button></a>";
}

  html += "</div>";

  //------------- Footer ------------------

  html += "<br><br>";

  html += "<center>";

  html += "<h3 style='color:#777;'>Designed by</h3>";

  html += "<h2 style='color:#1565C0;'>Theekshana Pradeep</h2>";

  html += "<p style='font-size:18px;color:#999;'>Smart Solar Monitor V2.1</p>";

  html += "</center>";

  html += "</body>";

  html += "</html>";

  return html;
} 

void handleRoot()
{
  server.send(200, "text/html", page());
}
void handleData()
{
    float batteryVoltage = readVoltage(BATTERY_VOLTAGE_PIN);
    float solarVoltage   = readVoltage(SOLAR_VOLTAGE_PIN);

    float batteryCurrent = readCurrent(BATTERY_CURRENT_PIN, batteryOffset);
    float solarCurrent   = readCurrent(SOLAR_CURRENT_PIN, solarOffset);

    float batteryPower = batteryVoltage * batteryCurrent;
    float solarPower   = solarVoltage * solarCurrent;

    int battery = batteryPercent(batteryVoltage);

    String json = "{";

    json += "\"batteryVoltage\":" + String(batteryVoltage,2) + ",";
    json += "\"batteryCurrent\":" + String(batteryCurrent,2) + ",";
    json += "\"batteryPower\":" + String(batteryPower,2) + ",";
    json += "\"batteryPercent\":" + String(battery) + ",";

    json += "\"solarVoltage\":" + String(solarVoltage,2) + ",";
    json += "\"solarCurrent\":" + String(solarCurrent,2) + ",";
    json += "\"solarPower\":" + String(solarPower,2) + ",";

    json += "\"motion\":" + String(digitalRead(PIR_PIN)) + ",";
    json += "\"light\":" + String(digitalRead(LDR_PIN)) + ",";

    json += "\"relay1\":" + String(relay1State) + ",";
    json += "\"relay2\":" + String(relay2State) + ",";

    json += "\"mode\":\"";

    if(autoMode)
        json += "AUTO";
    else
        json += "MANUAL";

    json += "\"}";

    server.send(200,"application/json",json);
}
void relay1On()
{
  if(autoMode)
  {
    server.sendHeader("Location","/");
    server.send(303);
    return;
  }

  digitalWrite(RELAY1,LOW);

  relay1State=true;

  server.sendHeader("Location","/");
  server.send(303);
}

void relay1Off()
{
  if(autoMode)
  {
    server.sendHeader("Location","/");
    server.send(303);
    return;
  }

  digitalWrite(RELAY1,HIGH);

  relay1State=false;

  server.sendHeader("Location","/");
  server.send(303);
}

void relay2On()
{
  if(autoMode)
  {
    server.sendHeader("Location","/");
    server.send(303);
    return;
  }

  digitalWrite(RELAY2,LOW);

  relay2State=true;

  server.sendHeader("Location","/");
  server.send(303);
}

void relay2Off()
{
  if(autoMode)
  {
    server.sendHeader("Location","/");
    server.send(303);
    return;
  }

  digitalWrite(RELAY2,HIGH);

  relay2State=false;

  server.sendHeader("Location","/");
  server.send(303);
}
//==============================
// Mode Selection
//==============================

void manualMode()
{
  autoMode = false;

  server.sendHeader("Location","/");
  server.send(303);
}

void autoModeOn()
{
  autoMode = true;

  server.sendHeader("Location","/");
  server.send(303);
}

void setup()
{
  Serial.begin(115200);

  analogReadResolution(12);

  pinMode(PIR_PIN, INPUT);
  pinMode(LDR_PIN, INPUT);

  pinMode(RELAY1, OUTPUT);
  pinMode(RELAY2, OUTPUT);

  digitalWrite(RELAY1, HIGH);
  digitalWrite(RELAY2, HIGH);

  relay1State = false;
  relay2State = false;

  WiFi.mode(WIFI_AP);
  WiFi.softAP(ssid, password);

  Serial.println();
  Serial.println("==============================");
  Serial.println("SMART SOLAR MONITOR");
  Serial.println("==============================");
  Serial.print("IP Address : ");
  Serial.println(WiFi.softAPIP());

  server.on("/", handleRoot);
  server.on("/data", handleData);
  server.on("/manual", manualMode);

server.on("/auto", autoModeOn);
  server.on("/r1on", relay1On);
server.on("/r1off", relay1Off);

server.on("/r2on", relay2On);
server.on("/r2off", relay2Off);

  server.begin();

  Serial.println("Web Server Started");
}

void loop()
{
  server.handleClient();

  if(autoMode)
  {
      //==========================
      // Relay 1 (Inverter)
      //==========================

      float batteryVoltage = readVoltage(BATTERY_VOLTAGE_PIN);

      int battery = batteryPercent(batteryVoltage);

      if(battery <= BATTERY_LIMIT)
      {
          digitalWrite(RELAY1,HIGH);

          relay1State=false;
      }
      else
      {
          digitalWrite(RELAY1,LOW);

          relay1State=true;
      }

      //==========================
      // Relay 2 (Light)
      //==========================

      bool night = digitalRead(LDR_PIN);

      bool motion = digitalRead(PIR_PIN);

      if(night)
      {
          if(motion)
          {
              digitalWrite(RELAY2,LOW);

              relay2State=true;

              motionTimer=millis();
          }

          if(relay2State)
          {
              if(millis()-motionTimer>LIGHT_DELAY)
              {
                  digitalWrite(RELAY2,HIGH);

                  relay2State=false;
              }
          }
      }
      else
      {
          digitalWrite(RELAY2,HIGH);

          relay2State=false;
      }
  }
}